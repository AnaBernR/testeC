#include <stdio.h>

main (){
  int n1,n2,soma;

  printf("Digite o primeiro numero: ");
  scanf("%d",&n1);
  printf("Digite o segundo numero: ");
  scanf("%i",&n2);
  soma = n1+n2;
  printf("A soma dos numeros é: %d", soma);
}